
#  Licensed to the Apache Software Foundation (ASF) under one
#  or more contributor license agreements.  See the NOTICE file
#  distributed with this work for additional information
#  regarding copyright ownership.  The ASF licenses this file
#  to you under the Apache License, Version 2.0 (the
#  "License"); you may not use this file except in compliance
#  with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing,
#  software distributed under the License is distributed on an
#  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
#  KIND, either express or implied.  See the License for the
#  specific language governing permissions and limitations
#  under the License.

"""Tests for Apache(TM) Bloodhound's tickets notifications 
in product environments"""

import unittest

from trac.tests.notification import SMTPThreadedServer
from trac.ticket.tests import notification

from tests.env import ProductEnvironmentStub as ProductEnvironment
from tests.env import MultiproductTestCase

class ProductNotificationTestCase(notification.NotificationTestCase, 
        MultiproductTestCase):

    @property
    def env(self):
        env = getattr(self, '_env', None)
        if env is None:
            self.global_env = self._setup_test_env()
            self._upgrade_mp(self.global_env)
            self._setup_test_log(self.global_env)
            self._load_product_from_data(self.global_env, self.default_product)
            self._env = env = ProductEnvironment(
                    self.global_env, self.default_product)
            self._load_default_data(self._env)
        return env

    @env.setter
    def env(self, value):
        pass

    def tearDown(self):
        notification.notifysuite.tear_down()
        self.global_env.reset_db()

class ProductNotificationTestSuite(notification.NotificationTestSuite):
    def __init__(self):
        """Start the local SMTP test server"""
        notification.NotificationTestSuite.__init__(self)
        self._tests = []
        self.addTest(unittest.makeSuite(ProductNotificationTestCase, 'test'))


def test_suite():
    if not notification.notifysuite:
        notification.notifysuite = ProductNotificationTestSuite()
    return notification.notifysuite

if __name__ == '__main__':
    unittest.TextTestRunner(verbosity=2).run(test_suite())

